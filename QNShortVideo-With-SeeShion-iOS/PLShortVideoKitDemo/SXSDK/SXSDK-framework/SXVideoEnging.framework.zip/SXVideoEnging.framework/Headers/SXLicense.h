//
//  SXLicense.h
//  SXVideoEnging
//
//  Created by Yin Xie on 2019/3/12.
//  Copyright © 2019 Zhiqiang Li. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef enum : NSUInteger {
    SXCustomTemplate = 0,                   // 由用户手动调用接口创建的模板
    SXFeatureTypeNormalTemplate = 1,        // 从ve文件载入的普通模板，只支持固定数量的素材
    SXFeatureTypeDynamicTemplate = 1 << 1   // 从ve文件载入的动态模板，支持随机数量的素材
} SXFeatureType;

@interface SXLicense : NSObject


/**
 * 注册license
 * @warning 该方法应该只被调用一次
 * @param license license字符串
 */
+(void)setLicense:(NSString *)license;

/**
 检查证书是否可用
 @return 返回是否可用
 */
+ (BOOL)isLicenseValid;

/**
 获取icense平台

 @return 平台类型 0:Server, 1:IOS, 2:Android, 3：Exporter
 */
+ (int)getPlatform;

/**
 获取平台字符串描述

 @return 平台类型字符串
 */
+ (NSString *)getPlatformString;

/**
 获取bundle name

 @return bundle name
 */
+ (NSString *)getBundleName;

/**
 获取license版本

 @return 版本号
 */
+ (NSString *)getVersion;

/**
 获取license类型

 @return 0:正式版, 1:测试版
 */
+ (int)getLicenseType;

/**
 获取测试license过期时间

 @return 测试版本过期时间
 */
+ (NSString *)getTestExpire;

/**
 　检查产品是否可用
 
 @param type 产品类型
 @return 没有对应的产品信息返回false， 否则返回true
 */
+ (BOOL)checkFeature:(SXFeatureType)type;

@end

NS_ASSUME_NONNULL_END
